#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## INTROTOR/BASICS/INTROTOR BASICS 2 ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#=================================================-
#### Slide 20: Good coding practices: libraries first  ####

Error in file(file, "rt") : cannot open the connection Calls: <Anonymous> ... withVisible( -> eval -> -> read.csv -> read.table -> file


#=================================================-
#### Slide 23: Exercise  ####




#######################################################
####  CONGRATULATIONS ON COMPLETING THIS MODULE!   ####
#######################################################
